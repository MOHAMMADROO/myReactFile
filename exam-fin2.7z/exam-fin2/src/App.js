import { useState ,useRef } from "react";
import Header from "./components/Header";
import flight_data from "./flight_data";
import FlightList from "./components/FlightList";
import FlightAddForm from "./components/FlightAddForm";

function App() {
  const [flightData, setFlightData] = useState(flight_data);

  //const addFlight=()=>{
  //const newFlightList=[...flightList,newFlight]
  

//  }

  

 
  

  const handleFlight = flightData.map((flight, i) => {
    return (<>
      <FlightList flight={flight} />
    </>);
  });

  const [loggedIn,setLoggedIn]=useState(false);



  return (
    <>
      <Header loggedIn={loggedIn} setLoggedIn={setLoggedIn} />

      <FlightAddForm loggedIn={loggedIn} setLoggedIn={setLoggedIn}/>

      <main>
        <ul id="flightList">
          
            {handleFlight}
            
          
        </ul>
      </main>
    </>
  );
}

export default App;

import './Header.css'

const Header=({loggedIn,setLoggedIn})=>{
    const handleLogIn=()=>{
        
            setLoggedIn(!loggedIn)

        
    }
    let loggedInText=loggedIn===true?'login':'logout'

    return(
        <>
             <header className="headerWrapper">
            <div className="headerInner">
            <span className="title">Flights</span>
            <button className="login" onClick={ handleLogIn} >{loggedInText} </button>
            </div>
            </header>
        
        </>
    )
}

export default Header;
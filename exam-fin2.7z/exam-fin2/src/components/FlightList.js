import { useState } from "react"
import flight_data from "../flight_data";

const FlightList=(props)=>{

const [flightList,setFlightList]=useState([]);    
const deleteFlight=(props)=>{
    const newFlightList=flightList.filter((flight)=>{
        if (props.flight.flightNumber===flight) return false
        else return true
    })
    setFlightList(newFlightList);
}

    return(
        <li>
            <h2 key={props.flight.flightNumber} > number :{props.flight.flightNumber} </h2>
            <h4  >date :{props.flight.flightDate} </h4>
            <h5  style={{border:props.flight.flightType==='charter'&&'2px dashed red'}}>type:{props.flight.flightType} </h5>
            <button onClick={()=>deleteFlight(flightList.flight)} >X</button> 
        </li>
    )
}

export default FlightList;
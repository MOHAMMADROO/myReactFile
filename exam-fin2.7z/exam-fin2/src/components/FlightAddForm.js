import { useRef, useState } from "react";
const FlightAddForm=(props)=>{

    const numberRef=useRef();
    const dateRef=useRef();
    const typeRef=useRef();

    const [numberIsValid,setNumberIsValid]=useState(false);
    const [dateIsValid,setDateIsValid]=useState(false);
    const validTypes=['scheduled','charter','private'];
    const [typeIsValid,setTypeIsValid]=useState(validTypes);
    

   const addHandler=(event)=>{
        event.preventDefault();
        const newFlight={
            flightNumber:numberRef.current.value,
            flightDate:dateRef.current.value,
            flightType:typeRef.current.value
        }

        if(numberRef.current.value.trim()==''){
            setNumberIsValid(false);
            return;
        }
        setNumberIsValid(true);

        if(dateRef.current.value.trim()==''){
            setDateIsValid(false);
        }
        setDateIsValid(true);

        if(typeRef.current.value!==validTypes){
            setTypeIsValid(false);
            return
        }
        setTypeIsValid(true);
    }

    

    return(
        <>
        <form onSubmit={addHandler}>
        <div className="flightForm">
        <div className="flightFormContent">
          <label htmlFor="flightNumber">Flight number</label>
          <input type="text" name="flightNumber" id="flighNumber" ref={numberRef}  required/>

          !numberIsValid && <span style={{color:'red'}}/>
          <label htmlFor="flightDate">Date</label>
          <input type="date" name="flightDate" id="flightDate" ref={dateRef} required />
          <label htmlFor="flightType">
            Flight type (scheduled, charter, private)
          </label>
          <input type="text" name="flightType" id="flighType" ref={typeRef} required/>
        </div>
        <div className="flightFormActions">
          <button id="addFlight" disabled={props.loggedIn} onClick={addHandler} >Add</button>
          <button id="cancelFlight">Cancel</button>
        </div>
      </div>
      </form>
      </>

    )
}

export default FlightAddForm;